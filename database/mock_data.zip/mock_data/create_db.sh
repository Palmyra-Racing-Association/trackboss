#!/bin/bash
sudo mysql --user=root --password=test123 -e "source InitSchema.sql"

